document.addEventListener('DOMContentLoaded', function() {
  const board = document.getElementById('board');
  const status = document.getElementById('status');
  const newGameBtn = document.getElementById('new-game-btn');

  let currentPlayer = 'X';
  let moves = 0;
  let boardState = ['', '', '', '', '', '', '', '', ''];

  function renderBoard() {
    board.innerHTML = '';
    boardState.forEach((cell, index) => {
      const cellElement = document.createElement('div');
      cellElement.classList.add('cell');
      cellElement.textContent = cell;
      cellElement.addEventListener('click', () => handleMove(index));
      board.appendChild(cellElement);
    });
  }

  function handleMove(index) {
    if (boardState[index] === '') {
      boardState[index] = currentPlayer;
      moves++;
      renderBoard();
      if (checkWin() || moves === 9) {
        endGame();
      } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        status.textContent = `Player ${currentPlayer}'s turn`;
      }
    }
  }

  function checkWin() {
    const winConditions = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
    ];
    return winConditions.some((condition) => {
      const [a, b, c] = condition;
      return boardState[a] && boardState[a] === boardState[b] && boardState[a] === boardState[c];
    });
  }

  function endGame() {
    if (checkWin()) {
      status.textContent = `Player ${currentPlayer} wins!`;
    } else {
      status.textContent = 'It\'s a draw!';
    }
    newGameBtn.style.display = 'block';
    board.innerHTML = '';
  }

  function resetGame() {
    currentPlayer = 'X';
    moves = 0;
    boardState = ['', '', '', '', '', '', '', '', ''];
    renderBoard();
    status.textContent = `Player ${currentPlayer}'s turn`;
    newGameBtn.style.display = 'none';
  }

  newGameBtn.addEventListener('click', resetGame);

  renderBoard();
  status.textContent = `Player ${currentPlayer}'s turn`;
});
